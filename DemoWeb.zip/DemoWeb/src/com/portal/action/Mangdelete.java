package com.portal.action;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Mangdelete
 */
@WebServlet("/Mangdelete")
public class Mangdelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
  	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

			int id=Integer.parseInt(request.getParameter("id"));
		
		try {
			Class.forName("org.h2.Driver");
			Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/Job_portal", "sa", "sa");

			
			PreparedStatement pst=con.prepareStatement("DELETE FROM `login_details`  WHERE id=?");
			pst.setInt(1, id);
			int i=pst.executeUpdate();
			if(i!=0) {
				response.sendRedirect("/DemoWeb/Manager");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
   
		
  	}
}
