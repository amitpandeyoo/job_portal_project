package com.portal.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.portal.dao.EmpDao;
import com.portal.dao.HrDao;
import com.portal.model.EmpModel;

/**
 * Servlet implementation class Hr
 */
@WebServlet("/Hr")
public class Hr extends HttpServlet {
	private static final long serialVersionUID = 1L;
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
HrDao dao =new HrDao();
EmpModel emp;
		
List<EmpModel> al = new ArrayList<>();
List<EmpModel> ul = new ArrayList<>();

ul=dao.getfalse();
al=dao.gettrue();
request.setAttribute("alist", al);
request.setAttribute("ulist", ul);
javax.servlet.RequestDispatcher rd = request.getRequestDispatcher("HR-page.jsp");
rd.forward(request, response);



   }

}
