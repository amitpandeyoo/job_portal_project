package com.portal.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.portal.dao.EmpDao;
import com.portal.model.EmpModel;

/**
 * Servlet implementation class Manager
 */
@WebServlet("/Manager")
public class Manager extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		EmpDao dao =new EmpDao();
		EmpModel emp;
				
		List<EmpModel> al = new ArrayList<>();
		List<EmpModel> ul = new ArrayList<>();

		ul=dao.maggetfalse();
		al=dao.maggettrue();
		
		request.setAttribute("alist", al);
		request.setAttribute("ulist", ul);
		
		javax.servlet.RequestDispatcher rd = request.getRequestDispatcher("Manager-page.jsp");
		rd.forward(request, response);

	}
}
