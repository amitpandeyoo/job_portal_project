package com.portal.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.portal.dao.EmpDao;
import com.portal.model.EmpModel;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		EmpDao dao=new EmpDao();
		EmpModel model=new EmpModel();
		String email=request.getParameter("email");
		String pass=request.getParameter("pass");
		String role=request.getParameter("role");
		
		model=dao.login(email);
		System.out.println(email + pass + role);
		System.out.println(model.getPassword() +" "+ model.getRole() +" "+ model.getEmail()+ " ");
		if(model.getPassword().equals(pass)) {
			if(model.getRole().equalsIgnoreCase("HR") && role.equals(model.getRole())) {
				response.sendRedirect("/DemoWeb/Hr");
				System.out.println("HR LogIn");
			}else if(model.getRole().equalsIgnoreCase("MANAGER") && role.equals(model.getRole())) {
				response.sendRedirect("/DemoWeb/Manager");
				System.out.println("MANAGER LogIn");
			}else if(model.getRole().equalsIgnoreCase("EMPLOYEE") && role.equals(model.getRole())) {
				response.sendRedirect("index.jsp");
				System.out.println("EMPLOYEE LogIn");
			}
		}else {
			System.out.println("Login Invalid");
		}
		
	}
}
