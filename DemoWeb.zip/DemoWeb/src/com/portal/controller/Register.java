package com.portal.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.portal.dao.EmpDao;
import com.portal.model.EmpModel;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
String fname=request.getParameter("fname");
String lname=request.getParameter("lname");
String email=request.getParameter("email");
String pass=request.getParameter("upass");
String role=request.getParameter("role");
String gender=request.getParameter("gender");
		
EmpDao dao=new EmpDao();
EmpModel mo=new EmpModel(fname, lname, email, pass, role, gender, false);
boolean done=dao.register(mo);
if(done) {
	response.sendRedirect("login.jsp");
	System.out.println("Register");
}
	}

}
