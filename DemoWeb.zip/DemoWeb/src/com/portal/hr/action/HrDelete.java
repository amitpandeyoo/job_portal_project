package com.portal.hr.action;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HrDelete
 */
@WebServlet("/HrDelete")
public class HrDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		int id=Integer.parseInt(request.getParameter("id"));
		try {
			Class.forName("org.h2.Driver");
			Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/Job_portal", "sa", "sa");
			PreparedStatement pst = con.prepareStatement("DELETE FROM `login_details`  WHERE id=?");
			pst.setInt(1, id);
			int i=pst.executeUpdate();
			if(i!=0) {
				response.sendRedirect("/DemoWeb/Hr");
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	
   
   }
}
