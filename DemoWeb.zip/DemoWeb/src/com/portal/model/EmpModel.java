package com.portal.model;

public class EmpModel {

	int id;
	String Firstname, LastName, Email, password, profession, gender, role;

	public EmpModel() {

	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	Boolean approve;

	public void EmpModel() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstname() {
		return Firstname;
	}

	public void setFirstname(String firstname) {
		Firstname = firstname;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Boolean getApprove() {
		return approve;
	}

	public void setApprove(Boolean approve) {
		this.approve = approve;
	}

	public EmpModel(String fname, String lName, String email, String pass, String role, String gender,
			Boolean approve) {

		this.Firstname = fname;
		this.LastName = lName;
		this.Email = email;
		this.password = pass;
		this.role = role;
		this.gender = gender;
		this.approve = approve;
	}

}
