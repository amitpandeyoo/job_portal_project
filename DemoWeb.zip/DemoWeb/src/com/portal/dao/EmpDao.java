package com.portal.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.portal.model.EmpModel;

public class EmpDao<Employee> {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	List<EmpModel> al;
	List<EmpModel> ul;
	

	public void connection() {
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/Job_portal", "sa", "sa");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public boolean register(EmpModel m) {
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/Job_portal", "sa", "sa");
			pst = con.prepareStatement(
					"INSERT INTO `login_details`(`Firstname`, `LastName`, `Email`, `password`, `role`, `gender`, `approve`)"
							+ " VALUES (?,?,?,?,?,?,?)");
			pst.setString(1, m.getFirstname());
			pst.setString(2, m.getLastName());
			pst.setString(3, m.getEmail());
			pst.setString(4, m.getPassword());
			pst.setString(5, m.getRole());
			pst.setString(6, m.getGender());
			pst.setInt(7, 0);
			int i = pst.executeUpdate();
			if (i != 0) {
				return true;
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		return false;
	}

	public EmpModel login(String email) {
		EmpModel model = new EmpModel();
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/Job_portal", "sa", "sa");
			pst = con.prepareStatement("select * from `login_details` where `Email`=?");
			pst.setString(1, email);
			
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				
				model.setRole(rs.getString("role"));
				model.setPassword(rs.getString("password"));
				model.setEmail(rs.getString("email"));
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		return model;
	}

	
	
	public List<EmpModel> maggettrue() {
		al = new ArrayList<>();
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/Job_portal", "sa", "sa");
			pst = con.prepareStatement("select * from `login_details` where `manager`=1");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				EmpModel model = new EmpModel();
				model.setId(Integer.parseInt(rs.getString("id")));
				model.setFirstname(rs.getString("firstname"));
				model.setLastName(rs.getString("lastName"));
				model.setGender(rs.getString("gender"));
				model.setRole(rs.getString("role"));
				model.setPassword(rs.getString("password"));
				model.setEmail(rs.getString("email"));
				al.add(model);
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return al;
	}
	
	public List<EmpModel> maggetfalse() {
		ul = new ArrayList<>();
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/Job_portal", "sa", "sa");
			pst = con.prepareStatement("select * from `login_details` where `approve`=1 ");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				EmpModel model = new EmpModel();
				model.setId(Integer.parseInt(rs.getString("id")));
				model.setFirstname(rs.getString("firstname"));
				model.setLastName(rs.getString("lastName"));
				model.setGender(rs.getString("gender"));
				model.setRole(rs.getString("role"));
				model.setPassword(rs.getString("password"));
				model.setEmail(rs.getString("email"));
				ul.add(model);
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return ul;
	}
}
