package com.portal.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.portal.model.EmpModel;

public class HrDao {

	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	List<EmpModel> al;
	List<EmpModel> ul;

	
	public List<EmpModel> getfalse() {
		al = new ArrayList<>();
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/Job_portal", "sa", "sa");
			pst = con.prepareStatement("select * from `login_details` where `approve`=0");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				EmpModel model = new EmpModel();
				model.setId(Integer.parseInt(rs.getString("id")));
				model.setFirstname(rs.getString("firstname"));
				model.setLastName(rs.getString("lastName"));
				model.setGender(rs.getString("gender"));
				model.setRole(rs.getString("role"));
				model.setPassword(rs.getString("password"));
				model.setEmail(rs.getString("email"));
				al.add(model);
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return al;
	}

	public List<EmpModel> gettrue() {
		ul = new ArrayList<>();
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/Job_portal", "sa", "sa");
			pst = con.prepareStatement("select * from `login_details` where `approve`=1");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				EmpModel model = new EmpModel();
				model.setId(Integer.parseInt(rs.getString("id")));
				model.setFirstname(rs.getString("firstname"));
				model.setLastName(rs.getString("lastName"));
				model.setGender(rs.getString("gender"));
				model.setRole(rs.getString("role"));
				model.setPassword(rs.getString("password"));
				model.setEmail(rs.getString("email"));
				ul.add(model);
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return ul;
	}
	
	
}
